const infosJoji = document.getElementById("infos-Joji");
const infosLevi = document.getElementById("infos-Levi");
const infosVivian = document.getElementById("infos-Vivian");


function toggleJoji() {
    if (infosJoji.style.display === "none") {
      infosJoji.style.display = "block";
    } else {
      infosJoji.style.display = "none";
    }
  }

  function toggleLevi() {
    if (infosLevi.style.display === "none") {
      infosLevi.style.display = "block";
    } else {
      infosLevi.style.display = "none";
    }
  }

  function toggleVivian() {
    if (infosVivian.style.display === "none") {
      infosVivian.style.display = "block";
    } else {
      infosVivian.style.display = "none";
    }
  }